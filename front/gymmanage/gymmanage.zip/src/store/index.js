import { createStore } from 'vuex'

export default createStore({
  state: {
    userAccount:null,
    isLogin:false,
  },
  getters: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})
